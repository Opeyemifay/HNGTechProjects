DROP DATABASE `HNGHireModel`;
CREATE DATABASE `HNGHireModel`;
USE `HNGHireModel`;


-- Table for Candidates
CREATE TABLE Candidates (
    CandidateID INT PRIMARY KEY AUTO_INCREMENT,
    Name VARCHAR(100) NOT NULL,
    Email VARCHAR(100) NOT NULL UNIQUE,
    Phone VARCHAR(20),
    Stack VARCHAR(50),
    Experience INT,
    Status VARCHAR(50)
);

-- Table for Jobs
CREATE TABLE Jobs (
    JobID INT PRIMARY KEY AUTO_INCREMENT,
    StackName VARCHAR(50) NOT NULL,
    Description TEXT,
    Requirements TEXT,
    Openings INT
);

-- Table for Applications
CREATE TABLE Applications (
    ApplicationID INT PRIMARY KEY AUTO_INCREMENT,
    CandidateID INT,
    JobID INT,
    ApplicationDate DATE NOT NULL,
    ApplicationStatus VARCHAR(50),
    FOREIGN KEY (CandidateID) REFERENCES Candidates(CandidateID),
    FOREIGN KEY (JobID) REFERENCES Jobs(JobID)
);

CREATE TABLE Interviewers (
    InterviewerID INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(100),
    Email VARCHAR(100),
    Phone VARCHAR(15),
    OrganizationName VARCHAR(100)
);

-- Table for Interviews
CREATE TABLE Interviews (
    InterviewID INT PRIMARY KEY AUTO_INCREMENT,
    CandidateID INT,
    JobID INT,
    InterviewerID INT,
    InterviewDate DATE NOT NULL,
    Feedback TEXT,
    Result VARCHAR(50),
    FOREIGN KEY (CandidateID) REFERENCES Candidates(CandidateID),
    FOREIGN KEY (JobID) REFERENCES Jobs(JobID),
    FOREIGN KEY (InterviewerID)  REFERENCES Interviewers(InterviewerID)
);

-- Table for Hiring
CREATE TABLE Hiring (
    HiringID INT PRIMARY KEY AUTO_INCREMENT,
    CandidateID INT,
    JobID INT,
    HiringStatus VARCHAR(50),
    HiringDate DATE NOT NULL,
    FOREIGN KEY (CandidateID) REFERENCES Candidates(CandidateID),
    FOREIGN KEY (JobID) REFERENCES Jobs(JobID)
);




SELECT * FROM Candidates;
SELECT * FROM Jobs;
SELECT * FROM Applications;
SELECT * FROM Interviews;
SELECT * FROM Hiring;
SELECT * FROM Interviewers;
SELECT CandidateID FROM Candidates;

-- Total Number of Candidates Per Stack:
-- This query will give you the count of candidates grouped by their stack.
SELECT Stack, COUNT(*) AS TotalCandidatescandidates
FROM Candidates
GROUP BY Stack;

-- Available Candidates Per Stack:
-- This query will show you the candidates who are currently active and available for hiring, grouped by stack.
SELECT Stack, COUNT(*) AS AvailableCandidates
FROM Candidates
WHERE Status = 'Available'
GROUP BY Stack;

-- Candidates in Interviews Per Stack:
-- This query will show the number of candidates who are currently in the interview process, grouped by stack.
SELECT j.StackName, COUNT(*) AS CandidatesInInterview
FROM Applications a
JOIN Jobs j ON a.JobID = j.JobID
WHERE a.ApplicationStatus = 'In Review'
GROUP BY j.StackName;

-- Candidates Hired Per Stack:
-- This query will show the number of candidates who have been hired, grouped by stack.
SELECT j.StackName, COUNT(*) AS HiredCandidates
FROM Hiring h
JOIN Jobs j ON h.JobID = j.JobID
WHERE h.HiringStatus = 'Accepted'
GROUP BY j.StackName;

-- Applications Status Overview:
-- This query will give you an overview of the status of applications (e.g., Pending, Interviewing, Rejected) for each stack.
SELECT j.StackName, a.ApplicationStatus, COUNT(*) AS TotalApplications
FROM Applications a
JOIN Jobs j ON a.JobID = j.JobID
GROUP BY j.StackName, a.ApplicationStatus;

-- Hiring Summary:
-- This query will give a summary of hiring outcomes (Hired, Not Hired) across all stacks.
SELECT j.StackName, h.HiringStatus, COUNT(*) AS HiringCount
FROM Hiring h
JOIN Jobs j ON h.JobID = j.JobID
GROUP BY j.StackName, h.HiringStatus;

-- Join Tables
SELECT 
    c.Stack,
    COUNT(i.CandidateID) AS NumberOfInterviews
FROM 
    Interviews i
JOIN 
    Candidates c ON i.CandidateID = c.CandidateID
JOIN 
    Jobs j ON i.JobID = j.JobID
GROUP BY 
    c.Stack;
